filename PF9A7BA2 list;

 %put NOTE- ;
 %put NOTE: Loading package FASTCAS, version 0.1, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-11-09T16:38:19; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(FASTCAS) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  PF9A7BA2(packagemetadata.sas) / nosource2; 

 data _null_;                                    
  call symputX("packageRequiredErrors", 0, "L"); 
 run;                                            
 %put NOTE- *Testing required SAS components*%sysfunc(DoSubL(%str(
 options nonotes nosource ;                          
 options ls=max ps=max locale=en_US ;                
 /* temporary redirect log */                        
 filename _stinit_ TEMP ;                            
 proc printto log = _stinit_ ; run ;                 
 /* print out setinit */                             
 proc setinit ; run ;                                
 proc printto ; run ;                                
 options ps=min ;                                    
 data _null_ ;                                       
   /* loadup checklist of required SAS components */ 
   if _n_ = 1 then                                   
     do ;                                            
       length req $ 256 ;                            
       declare hash R() ;                            
       _N_ = R.defineKey("req") ;                    
       _N_ = R.defineDone() ;                        
       declare hiter iR("R") ;                       
         do req = %bquote(
"BASE SAS SOFTWARE", "CLOUD ANALYTIC SERVICES"
) ; 
          _N_ = R.add(key:req,data:req) ;            
         end ;                                       
     end ;                                           
                                                     
   /* read in output from proc setinit */            
   infile _stinit_ end=eof ;                         
   input ;                                           
                                                     
   /* if component is in setinit remove it from checklist */ 
   if _infile_ =: "---" then                         
     do ;                                            
       req = upcase(substr(_infile_, 4, 64)) ;       
       if R.find(key:req) = 0 then                   
         do ;                                        
           _N_ = R.remove() ;                        
         end ;                                       
     end ;                                           
                                                     
   /* if checklist is not null rise error */         
   if eof and R.num_items > 0 then                   
     do ;                                            
       put "WARNING- ###########################################" ; 
       put "WARNING:  The following SAS components are missing! " ; 
       call symputX("packageRequiredErrors", 0, "L") ;              
       do while(iR.next() = 0) ;                                    
         put "WARNING-   " req ;                                    
       end ;                                                        
       put "WARNING:  The package may NOT WORK as expected      " ; 
       put "WARNING:  or even result with ERRORS!               " ; 
       put "WARNING- ###########################################" ; 
       put ;                                         
     end ;                                           
 run ;                                               
 filename _stinit_ clear ;                           
 options notes source ;                              
 )))*;                                               
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_;                                                     
  if 1 = symgetn("packageRequiredErrors") then                    
    do;                                                           
      put "ERROR: Loading package &packageName. will be aborted!";
      put "ERROR- Required components are missing.";              
      put "ERROR- *** STOP ***";                                  
      call symputX("packageRequiredErrors",
     'options ls = &ls_tmp. ps = &ps_tmp. 
       &notes_tmp. &source_tmp. msglevel=&msglevel_tmp. 
       &stimer_tmp. &fullstimer_tmp. ;
       data _null_;abort;run;', "L");              
    end;                                            
  else                                              
    call symputX("packageRequiredErrors", " ", "L");
 run;                                               
 &packageRequiredErrors.                            
 options &temp_noNotes_etc.;                        
 
%if (%str(*)=%superq(cherryPick)) or (cas2sashdat_macro in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "cas2sashdat_macro.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(cas2sashdat_macro)=1, NOTE# Macro cas2sashdat_macro exist. It will be overwritten by the macro from the FASTCAS package, ));
  %include PF9A7BA2(_001_macro.cas2sashdat_macro.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (csv2cas_macro in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "csv2cas_macro.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(csv2cas_macro)=1, NOTE# Macro csv2cas_macro exist. It will be overwritten by the macro from the FASTCAS package, ));
  %include PF9A7BA2(_001_macro.csv2cas_macro.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sas2cas_macro in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sas2cas_macro.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sas2cas_macro)=1, NOTE# Macro sas2cas_macro exist. It will be overwritten by the macro from the FASTCAS package, ));
  %include PF9A7BA2(_001_macro.sas2cas_macro.sas) / nosource2;
%end; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;                                   
length CASLUDF $ 32767;                        
dtCASLudf = datetime();                        
CASLUDF =                                      
    '%macro FASTCASCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for FASTCAS package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `FASTCASCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20260727.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                           
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'
 !! "  filename PF9A7BA2 &ZIP. '&path./fastcas.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename PF9A7BA2 clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

data _null_;
run;
data _null_;
run;
%if (%str(*)=%superq(cherryPick)) %then %do;
proc fcmp outlib = work.FASTCASfcmp.packagemeta ; 
 function FASTCASMETA(meta $) $ 32767;
  m = char(upcase(meta),1);
   if m = 'V' then return(strip("0.1"));
   if m = 'D' then return(strip("2026-11-09T16:38:19"));
   if m = 'A' then return(strip("Dave Kestner (dave.kestner@sas.com)"));
   if m = 'M' then return(strip("Dave Kestner (dave.kestner@sas.com)"));
   if m = 'T' then return(strip("Package for interacting with CAS"));
   if m = 'E' then return(strip("UTF8"));
   if m = 'L' then return(strip("2026-11-09T16:38:19"));
   if m = 'S' then return(strip("""BASE SAS SOFTWARE"", ""CLOUD ANALYTIC SERVICES"""));
  return(" ");
 endfunc;
quit;
%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.fastcasfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.fastcasfcmp);)
))
%macro FASTCASMETA(meta)/parmbuff;
%if %superq(meta) = %then %return;
%do;%qsysfunc(strip(%qsysfunc(FASTCASMETA&syspbuff.)))%end;
%mend;


%end;
%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

%if (%str(*)=%superq(cherryPick)) %then %do; 
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#fastcas(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'FASTCAS(0.1)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'FASTCAS(0.1)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'FASTCAS(0.1)', 'G');                            
      put / 'INFO: [SYSLOADEDPACKAGES] FASTCAS(0.1)';                                     
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
 options &temp_noNotes_etc.;
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package FASTCAS, version 0.1, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

