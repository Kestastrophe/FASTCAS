filename PF9A7BA2 list;
 %put NOTE- ;
 %put NOTE: Data for package FASTCAS, version 0.1, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-11-09T16:38:19; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(FASTCAS) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package FASTCAS, version 0.1, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
